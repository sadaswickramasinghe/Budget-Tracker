import os
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_pymongo import PyMongo
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
import datetime
from functools import wraps
from bson.objectid import ObjectId

app = Flask(__name__)
app.config.from_object('config.Config')

mongo = PyMongo(app)
users = mongo.db.users

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = session.get('token')
        if not token:
            return jsonify({'message': 'Token is missing!'}), 401
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = users.find_one({'email': data['email']})
        except:
            return jsonify({'message': 'Token is invalid!'}), 401
        return f(current_user, *args, **kwargs)
    return decorated

@app.route('/')
def home():
    return redirect(url_for('register'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        hashed_password = generate_password_hash(password)
        
        user = users.find_one({'email': email})
        if user:
            return 'Email address already exists'
        
        users.insert_one({'name': name, 'email': email, 'password': hashed_password, 'isadmin': False, 'categories': [], 'income': [], 'expenses': [], 'budget': []})
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        user = users.find_one({'email': email})
        if user and check_password_hash(user['password'], password):
            token = jwt.encode({
                'email': user['email'],
                'exp': datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(minutes=30)
            }, app.config['SECRET_KEY'], algorithm="HS256")
            session['token'] = token
            return redirect(url_for('dashboard'))
        return 'Invalid email or password'
    return render_template('login.html')

@app.route('/dashboard')
@token_required
def dashboard(current_user):
    user = users.find_one({'email': current_user['email']})
    income = user.get('income', [])
    expenses = user.get('expenses', [])
    budget = user.get('budget', [])
    categories = user.get('categories', [])
    return render_template('dashboard.html', income=income, expenses=expenses, budget=budget, categories=categories, name=user['name'])

@app.route('/logout')
def logout():
    session.pop('token', None)
    return redirect(url_for('login'))

@app.route('/add_category', methods=['GET', 'POST'])
@token_required
def add_category(current_user):
    if request.method == 'POST':
        category_name = request.form['category_name']
        users.update_one({'email': current_user['email']}, {'$push': {'categories': category_name}})
        return redirect(url_for('dashboard'))
    return render_template('add_category.html')

@app.route('/edit_category/<category>', methods=['GET', 'POST'])
@token_required
def edit_category(current_user, category):
    if request.method == 'POST':
        new_category_name = request.form['category_name']
        users.update_one({'email': current_user['email'], 'categories': category}, {'$set': {'categories.$': new_category_name}})
        return redirect(url_for('dashboard'))
    return render_template('edit_category.html', category=category)

@app.route('/delete_category/<category>')
@token_required
def delete_category(current_user, category):
    users.update_one({'email': current_user['email']}, {'$pull': {'categories': category}})
    return redirect(url_for('dashboard'))

@app.route('/add_income', methods=['GET', 'POST'])
@token_required
def add_income(current_user):
    if request.method == 'POST':
        source = request.form['source']
        amount = float(request.form['amount'])
        date = datetime.datetime.strptime(request.form['date'], '%Y-%m-%d')
        users.update_one({'email': current_user['email']}, {'$push': {'income': {'_id': ObjectId(), 'source': source, 'amount': amount, 'date': date}}})
        return redirect(url_for('dashboard'))
    return render_template('add_income.html')

@app.route('/edit_income/<income_id>', methods=['GET', 'POST'])
@token_required
def edit_income(current_user, income_id):
    income_id = ObjectId(income_id)
    user = users.find_one({'email': current_user['email'], 'income._id': income_id}, {'income.$': 1})
    if request.method == 'POST':
        source = request.form['source']
        amount = float(request.form['amount'])
        date = datetime.datetime.strptime(request.form['date'], '%Y-%m-%d')
        users.update_one({'email': current_user['email'], 'income._id': income_id}, {'$set': {'income.$.source': source, 'income.$.amount': amount, 'income.$.date': date}})
        return redirect(url_for('dashboard'))
    return render_template('edit_income.html', income=user['income'][0])

@app.route('/delete_income/<income_id>')
@token_required
def delete_income(current_user, income_id):
    income_id = ObjectId(income_id)
    users.update_one({'email': current_user['email']}, {'$pull': {'income': {'_id': income_id}}})
    return redirect(url_for('dashboard'))

@app.route('/add_expense', methods=['GET', 'POST'])
@token_required
def add_expense(current_user):
    if request.method == 'POST':
        category = request.form['category']
        amount = float(request.form['amount'])
        date = datetime.datetime.strptime(request.form['date'], '%Y-%m-%d')
        users.update_one({'email': current_user['email']}, {'$push': {'expenses': {'_id': ObjectId(), 'category': category, 'amount': amount, 'date': date}}})
        return redirect(url_for('dashboard'))
    categories = users.find_one({'email': current_user['email']}).get('categories', [])
    return render_template('add_expense.html', categories=categories)

@app.route('/edit_expense/<expense_id>', methods=['GET', 'POST'])
@token_required
def edit_expense(current_user, expense_id):
    expense_id = ObjectId(expense_id)
    user = users.find_one({'email': current_user['email'], 'expenses._id': expense_id}, {'expenses.$': 1})
    if request.method == 'POST':
        category = request.form['category']
        amount = float(request.form['amount'])
        date = datetime.datetime.strptime(request.form['date'], '%Y-%m-%d')
        users.update_one({'email': current_user['email'], 'expenses._id': expense_id}, {'$set': {'expenses.$.category': category, 'expenses.$.amount': amount, 'expenses.$.date': date}})
        return redirect(url_for('dashboard'))
    categories = users.find_one({'email': current_user['email']}).get('categories', [])
    return render_template('edit_expense.html', expense=user['expenses'][0], categories=categories)

@app.route('/delete_expense/<expense_id>')
@token_required
def delete_expense(current_user, expense_id):
    expense_id = ObjectId(expense_id)
    users.update_one({'email': current_user['email']}, {'$pull': {'expenses': {'_id': expense_id}}})
    return redirect(url_for('dashboard'))

@app.route('/set_budget', methods=['GET', 'POST'])
@token_required
def set_budget(current_user):
    if request.method == 'POST':
        category = request.form['category']
        amount = float(request.form['amount'])
        users.update_one({'email': current_user['email']}, {'$push': {'budget': {'_id': ObjectId(), 'category': category, 'amount': amount}}})
        return redirect(url_for('dashboard'))
    categories = users.find_one({'email': current_user['email']}).get('categories', [])
    return render_template('set_budget.html', categories=categories)

@app.route('/edit_budget/<budget_id>', methods=['GET', 'POST'])
@token_required
def edit_budget(current_user, budget_id):
    budget_id = ObjectId(budget_id)
    user = users.find_one({'email': current_user['email'], 'budget._id': budget_id}, {'budget.$': 1})
    if request.method == 'POST':
        category = request.form['category']
        amount = float(request.form['amount'])
        users.update_one({'email': current_user['email'], 'budget._id': budget_id}, {'$set': {'budget.$.category': category, 'budget.$.amount': amount}})
        return redirect(url_for('dashboard'))
    categories = users.find_one({'email': current_user['email']}).get('categories', [])
    return render_template('edit_budget.html', budget=user['budget'][0], categories=categories)

@app.route('/delete_budget/<budget_id>')
@token_required
def delete_budget(current_user, budget_id):
    budget_id = ObjectId(budget_id)
    users.update_one({'email': current_user['email']}, {'$pull': {'budget': {'_id': budget_id}}})
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
