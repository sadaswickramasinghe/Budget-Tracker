import unittest
import os
from app import app, mongo
from werkzeug.security import generate_password_hash
import jwt
import datetime
from bson.objectid import ObjectId

class BudgetAppTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        app.config['TESTING'] = True
        cls.app = app.test_client()
        cls.app.testing = True
        cls.db = mongo.db

    def setUp(self):
        # Ensure the test users are clean before each test
        self.test_user1 = {'name': 'Test User 1', 'email': 'test1@example.com', 'password': generate_password_hash('testpassword1')}
        self.test_user2 = {'name': 'Test User 2', 'email': 'test2@example.com', 'password': generate_password_hash('testpassword2')}
        
        # Register the test users
        if not self.db.users.find_one({'email': self.test_user1['email']}):
            self.db.users.insert_one(self.test_user1)
        if not self.db.users.find_one({'email': self.test_user2['email']}):
            self.db.users.insert_one(self.test_user2)

    def test_user_registration(self):
        response = self.app.post('/register', data=dict(
            name="Test User 3",
            email="test3@example.com",
            password="testpassword3"
        ))
        self.assertEqual(response.status_code, 302)  # Redirection indicates success
        # Clean up the newly registered test user
        self.db.users.delete_one({'email': 'test3@example.com'})

    def test_user_registration_existing_email(self):
        response = self.app.post('/register', data=dict(
            name="Test User",
            email="test1@example.com",
            password="testpassword"
        ))
        self.assertIn(b'Email address already exists', response.data)

    def test_user_login(self):
        response = self.app.post('/login', data=dict(
            email="test1@example.com",
            password="testpassword1"
        ))
        self.assertEqual(response.status_code, 302)  # Redirection indicates success

    def test_user_login_invalid(self):
        response = self.app.post('/login', data=dict(
            email="invalid@example.com",
            password="wrongpassword"
        ))
        self.assertIn(b'Invalid email or password', response.data)

    def test_protected_route_no_token(self):
        response = self.app.get('/dashboard')
        self.assertEqual(response.status_code, 401)

    def test_protected_route_invalid_token(self):
        with self.app.session_transaction() as session:
            session['token'] = 'invalid_token'
        response = self.app.get('/dashboard')
        self.assertEqual(response.status_code, 401)

    def test_add_category(self):
        with self.app.session_transaction() as session:
            session['token'] = jwt.encode({'email': 'test1@example.com', 'exp': datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(minutes=30)}, app.config['SECRET_KEY'], algorithm="HS256")
        response = self.app.post('/add_category', data=dict(category_name="New Category"))
        self.assertEqual(response.status_code, 302)  # Redirection indicates success
        # Clean up the added category
        self.db.users.update_one({'email': 'test1@example.com'}, {'$pull': {'categories': 'New Category'}})

    def test_add_income(self):
        with self.app.session_transaction() as session:
            session['token'] = jwt.encode({'email': 'test1@example.com', 'exp': datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(minutes=30)}, app.config['SECRET_KEY'], algorithm="HS256")
        response = self.app.post('/add_income', data=dict(source="Job", amount="1000", date="2023-01-01"))
        self.assertEqual(response.status_code, 302)  # Redirection indicates success
        # Clean up the added income
        self.db.users.update_one({'email': 'test1@example.com'}, {'$pull': {'income': {'source': 'Job', 'amount': 1000, 'date': datetime.datetime(2023, 1, 1)}}})

    def test_edit_income(self):
        income_id = ObjectId()
        self.db.users.update_one({'email': 'test1@example.com'}, {'$push': {'income': {'_id': income_id, 'source': 'Job', 'amount': 1000, 'date': datetime.datetime(2023, 1, 1)}}})
        with self.app.session_transaction() as session:
            session['token'] = jwt.encode({'email': 'test1@example.com', 'exp': datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(minutes=30)}, app.config['SECRET_KEY'], algorithm="HS256")
        response = self.app.post(f'/edit_income/{income_id}', data=dict(source="Freelance", amount="1500", date="2023-02-01"))
        self.assertEqual(response.status_code, 302)  # Redirection indicates success
        # Clean up the edited income
        self.db.users.update_one({'email': 'test1@example.com'}, {'$pull': {'income': {'_id': income_id}}})

    def test_delete_income(self):
        income_id = ObjectId()
        self.db.users.update_one({'email': 'test1@example.com'}, {'$push': {'income': {'_id': income_id, 'source': 'Job', 'amount': 1000, 'date': datetime.datetime(2023, 1, 1)}}})
        with self.app.session_transaction() as session:
            session['token'] = jwt.encode({'email': 'test1@example.com', 'exp': datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(minutes=30)}, app.config['SECRET_KEY'], algorithm="HS256")
        response = self.app.get(f'/delete_income/{income_id}')
        self.assertEqual(response.status_code, 302)  # Redirection indicates success

    def test_add_expense(self):
        with self.app.session_transaction() as session:
            session['token'] = jwt.encode({'email': 'test1@example.com', 'exp': datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(minutes=30)}, app.config['SECRET_KEY'], algorithm="HS256")
        response = self.app.post('/add_expense', data=dict(category="Food", amount="200", date="2023-01-01"))
        self.assertEqual(response.status_code, 302)  # Redirection indicates success
        # Clean up the added expense
        self.db.users.update_one({'email': 'test1@example.com'}, {'$pull': {'expenses': {'category': 'Food', 'amount': 200, 'date': datetime.datetime(2023, 1, 1)}}})

    def test_edit_expense(self):
        expense_id = ObjectId()
        self.db.users.update_one({'email': 'test1@example.com'}, {'$push': {'expenses': {'_id': expense_id, 'category': 'Food', 'amount': 200, 'date': datetime.datetime(2023, 1, 1)}}})
        with self.app.session_transaction() as session:
            session['token'] = jwt.encode({'email': 'test1@example.com', 'exp': datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(minutes=30)}, app.config['SECRET_KEY'], algorithm="HS256")
        response = self.app.post(f'/edit_expense/{expense_id}', data=dict(category="Transport", amount="300", date="2023-02-01"))
        self.assertEqual(response.status_code, 302)  # Redirection indicates success
        # Clean up the edited expense
        self.db.users.update_one({'email': 'test1@example.com'}, {'$pull': {'expenses': {'_id': expense_id}}})

    def test_delete_expense(self):
        expense_id = ObjectId()
        self.db.users.update_one({'email': 'test1@example.com'}, {'$push': {'expenses': {'_id': expense_id, 'category': 'Food', 'amount': 200, 'date': datetime.datetime(2023, 1, 1)}}})
        with self.app.session_transaction() as session:
            session['token'] = jwt.encode({'email': 'test1@example.com', 'exp': datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(minutes=30)}, app.config['SECRET_KEY'], algorithm="HS256")
        response = self.app.get(f'/delete_expense/{expense_id}')
        self.assertEqual(response.status_code, 302)  # Redirection indicates success

    def test_delete_user(self):
        # Test deleting one user (Test User 2)
        response = self.app.get('/delete_user/test2@example.com')  # Assuming you have a route to delete a user
        self.assertEqual(response.status_code, 302)  # Redirection indicates success
        user = self.db.users.find_one({'email': 'test2@example.com'})
        self.assertIsNone(user)  # Ensure the user is deleted

if __name__ == '__main__':
    unittest.main()
