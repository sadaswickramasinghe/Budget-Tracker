import unittest
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from pymongo import MongoClient

class BudgetAppRegisterTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        cls.driver.implicitly_wait(10)
        cls.driver.get("http://127.0.0.1:5000")
        cls.client = MongoClient('mongodb://127.0.0.1:27017/')
        cls.db = cls.client['BUDGET']
        cls.users = cls.db['users']

    @classmethod
    def tearDownClass(cls):
        cls.driver.quit()
        cls.client.close()

    def register_user(self, name, email, password):
        self.driver.get("http://127.0.0.1:5000/register")
        time.sleep(1)  # 2-second delay
        self.driver.find_element(By.NAME, "name").send_keys(name)
        time.sleep(1)  # 2-second delay
        self.driver.find_element(By.NAME, "email").send_keys(email)
        time.sleep(1)  # 2-second delay
        self.driver.find_element(By.NAME, "password").send_keys(password)
        time.sleep(1)  # 2-second delay
        self.driver.find_element(By.NAME, "password").send_keys(Keys.RETURN)
        time.sleep(1)  # 2-second delay

    def test_register_users(self):
        # Register users
        self.register_user("User 1", "user1@example.com", "password1")
        self.register_user("User 2", "user2@example.com", "password2")
        self.register_user("User 3", "user3@example.com", "password3")

        # Verify users in the database
        user1 = self.users.find_one({"email": "user1@example.com"})
        user2 = self.users.find_one({"email": "user2@example.com"})
        user3 = self.users.find_one({"email": "user3@example.com"})

        self.assertIsNotNone(user1)
        self.assertIsNotNone(user2)
        self.assertIsNotNone(user3)

if __name__ == '__main__':
    unittest.main()
