import unittest
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

class BudgetAppAddDataTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        cls.driver.implicitly_wait(10)
        cls.driver.get("http://127.0.0.1:5000")

    @classmethod
    def tearDownClass(cls):
        cls.driver.quit()

    def login_user(self, email, password):
        self.driver.get("http://127.0.0.1:5000/login")
        time.sleep(1)  # 1-second delay
        self.driver.find_element(By.NAME, "email").send_keys(email)
        time.sleep(1)  # 1-second delay
        self.driver.find_element(By.NAME, "password").send_keys(password)
        time.sleep(1)  # 1-second delay
        self.driver.find_element(By.NAME, "password").send_keys(Keys.RETURN)
        time.sleep(1)  # 1-second delay

    def add_category(self, category_name):
        self.driver.get("http://127.0.0.1:5000/add_category")
        time.sleep(1)  # 1-second delay
        self.driver.find_element(By.NAME, "category_name").send_keys(category_name)
        time.sleep(1)  # 1-second delay
        self.driver.find_element(By.NAME, "category_name").send_keys(Keys.RETURN)
        time.sleep(1)  # 1-second delay

    def add_income(self, source, amount, date):
        self.driver.get("http://127.0.0.1:5000/add_income")
        time.sleep(1)  # 1-second delay
        self.driver.find_element(By.NAME, "source").send_keys(source)
        time.sleep(1)  # 1-second delay
        self.driver.find_element(By.NAME, "amount").send_keys(amount)
        time.sleep(1)  # 1-second delay
        self.driver.find_element(By.NAME, "date").send_keys(date)
        time.sleep(1)  # 1-second delay
        self.driver.find_element(By.NAME, "date").send_keys(Keys.RETURN)
        time.sleep(1)  # 1-second delay

    def add_expense(self, category, amount, date):
        self.driver.get("http://127.0.0.1:5000/add_expense")
        time.sleep(1)  # 1-second delay
        self.driver.find_element(By.NAME, "category").send_keys(category)
        time.sleep(1)  # 1-second delay
        self.driver.find_element(By.NAME, "amount").send_keys(amount)
        time.sleep(1)  # 1-second delay
        self.driver.find_element(By.NAME, "date").send_keys(date)
        time.sleep(1)  # 1-second delay
        self.driver.find_element(By.NAME, "date").send_keys(Keys.RETURN)
        time.sleep(1)  # 1-second delay

    def test_add_data(self):
        # Login as User 1, add category, income, and expense
        self.login_user("user1@example.com", "password1")
        self.add_category("Salary")
        self.add_income("Job", "1000", "02.05.2024")
        self.add_expense("Food", "200", "02.05.2024")

        # Login as User 2, add category, income, and expense
        self.login_user("user2@example.com", "password2")
        self.add_category("Freelance")
        self.add_income("Freelance", "1500", "02.05.2024")
        self.add_expense("Transport", "300", "02.05.2024")

        # Login as User 3, add category, income, and expense
        self.login_user("user3@example.com", "password3")
        self.add_category("Investment")
        self.add_income("Investment", "2000", "02.05.2024")
        self.add_expense("Entertainment", "500", "02.05.2024")

if __name__ == '__main__':
    unittest.main()
